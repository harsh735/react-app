export default {
    API_ENDPOINT: 'http://localhost:5000/api',
    // API_ENDPOINT: 'https://[YOUR-ROUTE].mybluemix.net/api'
  };